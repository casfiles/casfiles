<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MY_Encryption extends CI_Encryption
{
	public function __construct()
    {
		parent::__construct(array('driver' => 'openssl'));
    }
	
    function encode($string,array $params = null)
    {
        $ret = parent::encrypt($string,$params);

        $ret = strtr(
			$ret,
			array(
				'+' => '.',
				'=' => '-',
				'/' => '~'
			)
		);
        return $ret;
    }


    function decode($string,array $params = null)
    {
        $string = strtr(
			$string,
			array(
				'.' => '+',
				'-' => '=',
				'~' => '/'
			)
		);

        return parent::decrypt($string,$params);
    }
}