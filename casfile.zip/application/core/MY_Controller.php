<?php
Class MY_Controller extends CI_Controller{
    
	public function __construct()
	{
		parent::__construct();
		has_access();
	}
	
	public function view($view, $vars = array(), $return = FALSE)
	{
		$this->load->view("common/header",$vars,$return);
		$this->load->view($view,$vars,$return);
		$this->load->view("common/footer",$vars,$return);
	}
}