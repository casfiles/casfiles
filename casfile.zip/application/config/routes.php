<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Home';
$route['forget-password'] = 'Home/forget_password';
$route['register-account'] = 'Home/register';
$route['logout'] = 'Dashboard/logout';
$route['dashboard'] ='Dashboard/index';
$route['profile']='Profile/index';

$route['departments']='Departments/index';
$route['add-department']='Departments/form';
$route['get-department-items']='Departments/ajax_get_items';
$route['edit-department/(:num)']='Departments/form/$1';
$route['delete-department/(:num)']='Departments/delete/$1';
$route['change-department-status/(:num)/(:any)']='Departments/change_status/$1/$2';


$route['teachers']='Teachers/index';
$route['add-teacher']='Teachers/form';
$route['get-teacher-items']='Teachers/ajax_get_items';
$route['edit-teacher/(:num)']='Teachers/form/$1';
$route['delete-teacher/(:num)']='Teachers/delete/$1';
$route['change-teacher-status/(:num)/(:any)']='Teachers/change_status/$1/$2';


$route['students']='Students/index';
$route['add-student']='Students/form';
$route['get-student-items']='Students/ajax_get_items';
$route['edit-student/(:num)']='Students/form/$1';
$route['delete-student/(:num)']='Students/delete/$1';
$route['change-student-status/(:num)/(:any)']='Students/change_status/$1/$2';

$route['cas-groups']='Cas/index';
$route['add-cas']='Cas/form';
$route['get-cas-items']='Cas/ajax_get_items';
$route['edit-cas/(:num)']='Cas/form/$1';
$route['delete-cas/(:num)']='Cas/delete/$1';
$route['change-cas-status/(:num)/(:any)']='Cas/change_status/$1/$2';


$route['cas-group-items']='Casitems/index';
$route['add-cas-item']='Casitems/form';
$route['get-cas-group-items']='Casitems/ajax_get_items';
$route['edit-cas-item/(:num)']='Casitems/form/$1';
$route['delete-cas-item/(:num)']='Casitems/delete/$1';
$route['change-cas-item-status/(:num)/(:any)']='Casitems/change_status/$1/$2';

$route['casform']='Casform/index';
$route['cas-submissions']='Submissions/index';
$route['get-submission-items']='Submissions/ajax_get_items';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
