<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("SettingsModel",'settings');
	}

	public function index()
	{
		$this->form_validation->set_rules('current_password', 'Current Password', 'required|callback_check_password');
		$this->form_validation->set_rules('new_password', 'New Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|callback_check_confirm_password');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger m-t-20">', '</div>');
		if($this->form_validation->run() === true)
		{
			$data	=	[
				"password"		=>	sha1($this->input->post("confirm_password")),
				"id"			=>	user()->id,
			];

			// update the user details in the database
			$response 	=	$this->settings->update_password($data,user()->account_type);
			if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	'Password updated successfully',
				];
			}else{
				$type 	=	[
					"type"	=>	"info",
					"msg"	=>	'Failed to update password',
				];
			}
			$this->session->set_flashdata("notification.settings",json_encode($type));
			redirect(site_url("settings"));
		}else{
			$page = [
				'title' => 'Settings | Account management',
				'breadcrumbs' => 'Settings',
				'pagecode'	=>	'settings'
			];

			return parent::view('settings/form',compact('page'));
		}
	}

	public function check_password($password)
	{
		$password = sha1($password);
		$is_valid = $this->settings->check_record(["id"=>user()->id,"password"=>$password],user()->account_type);

		if(!$is_valid)
		{
			$this->form_validation->set_message('check_password', 'Incorrect current password');
			return FALSE;
		}else{
			return true;
		}
	}

	public function check_confirm_password($password)
	{
		$new_password 		=	$this->input->post("new_password");
		$confirm_password 	=	$this->input->post("confirm_password");
		if($new_password != $confirm_password)
		{
			$this->form_validation->set_message('check_confirm_password', 'Password mismatch');
			return FALSE;
		}else{
			return true;
		}
	}
}
