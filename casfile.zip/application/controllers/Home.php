<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		isLoggedIn();
		
		$this->load->model("AdminModel");
	}
	
	public function index()
	{
		$this->form_validation->set_rules('email','Email','required|valid_email|callback_check_email');
		$this->form_validation->set_rules('password', 'Password', 'required|callback_check_password');
		$this->form_validation->set_message('email', 'The {field} field can not be empty');
		$this->form_validation->set_message('password', 'The {field} field can not be empty');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger m-t-20">', '</div>');
		if($this->form_validation->run() === true)
		{
			
			$email		=	$this->input->post("email");
			$password	=	$this->input->post("password");
			$login_type	=	$this->input->post("login_type");
			$user		=	$this->AdminModel->get(["email"=>$email,"password"=>sha1($password),"status"=>1],$login_type);
			$user->account_type = $login_type;

			if($user){
				$data = $this->encryption->encode(json_encode($user));
				$this->session->set_userdata("_user_session_data",$data);
				redirect(site_url("dashboard"));
			}else{
				redirect(site_url("/"));
			}
		}else{
			$this->load->view('login');
		}
	}

	public function check_email($email)
	{
		if(!empty($email))
		{
			$user	=	$this->AdminModel->get(["email"=>$email,"status"=>1],$this->input->post("login_type"));
			if (!$user->email)
			{
					$this->form_validation->set_message('check_email', 'The {field} does not have account associated with our database.');
					return FALSE;
			}else{
				return TRUE;
			}
		}else{
			$this->form_validation->set_message('check_email', 'The {field} is required.');
			return FALSE;
		}
		
	}
	
	public function check_password($password)
	{
		$email	=	$this->input->post("email");
		$password 	=	trim($password);
		$user	=	$this->AdminModel->get(["email"=>$email,"status"=>1],$this->input->post("login_type"));

		if(!empty($email)){
			if ($user->id && sha1($password) != $user->password )
			{
				$this->form_validation->set_message('check_password', 'You have entered wrong {field} for the email <b>'.$email.'</b>');
				return FALSE;
			}else{
				return TRUE;
			}
		}else{
			if(empty($password)){
				$this->form_validation->set_message('check_password', 'The {field} is required.');
				return FALSE;
			}
		}
		
	}
	public function forget_password()
	{
		return $this->load->view('forget-password');
	}

	public function register()
	{
		$this->form_validation->set_rules('first_name', 'First Name', 'required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_check_student_email');
		$this->form_validation->set_rules('password', 'password', 'required|min_length[8]');
		$this->form_validation->set_error_delimiters('<br/><div class="alert alert-danger">', '</div>');
		if($this->form_validation->run() === true)
		{
			$token 		=	random_string('alnum',30);
			$form 	=	[
				"first_name"	=>	$this->input->post("first_name"),
				"last_name"	=>	$this->input->post("last_name"),
				"email"		=>	$this->input->post("email"),
				"password"	=>	sha1($this->input->post("password")),
				"age"	=>	(int)$this->input->post("age"),
				"gender"	=>	$this->input->post("gender"),
				"contact_number"	=>	$this->input->post("contact_number"),
				"address"	=>	$this->input->post("address")
			];
			$response 	=	$this->AdminModel->save($form);
			//prd($response);
			if($response)
			{

				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	'Account created success fully!',
				];
			}else{
				$type 	=	[
					"type"	=>	"info",
					"msg"	=>	'Failed to create account',
				];
			}
			$this->session->set_flashdata("notification.register",json_encode($type));
			redirect(site_url("/"));
		}else{
			return $this->load->view('register');
		}
		
	}

	public function check_student_email($email)
	{
		if(!empty($email))
		{
			$user	=	$this->AdminModel->get(["email"=>$email,"status"=>1],'student');
			if ($user->email)
			{
					$this->form_validation->set_message('check_student_email', 'The {field} is already registered');
					return FALSE;
			}else{
				return TRUE;
			}
		}else{
			$this->form_validation->set_message('check_student_email', 'The {field} is required.');
			return FALSE;
		}
		
	}

}
