<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		
		$page = [
			'title' => 'Dashboard',
			'breadcrumbs' => 'Dashboard',
			'pagecode' => 'dashboard',
			'total_teachers' => $this->db->count_all_results('teachers'),
			'total_students' => $this->db->count_all_results('students'),
			'total_cas_groups' => $this->db->count_all_results('cas'),
			'total_submissions' => $this->db->count_all_results('cas_submissions'),
		];

		if(user()->account_type == 'admin'){
			$this->view('dashboard/dashboard-admin',compact('page'));
		}elseif(user()->account_type == 'teacher'){
			$this->view('dashboard/dashboard-teacher',compact('page'));
		}else{
			$this->view('dashboard/dashboard-student',compact('page'));
		}
		
	}

	public function logout()
	{
		$user_data = $this->session->all_userdata();

		foreach ($user_data as $key => $value) 
		{
			if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') 
			{
				$this->session->unset_userdata($key);
			}
		}
		$this->session->sess_destroy();

		redirect('/');
	}
}
