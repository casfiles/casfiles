<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("ProfileModel",'profile');
	}

	public function index()
	{
		$this->form_validation->set_rules('first_name', 'First name', 'required');
		$this->form_validation->set_rules('contact_number', 'Contact number', 'required|callback_check_contact_number');

		if(user()->account_type == 'teacher')
		{
			$this->form_validation->set_rules('department_id', 'Department', 'required');
		}

		$this->form_validation->set_error_delimiters('<div class="alert alert-danger m-t-20">', '</div>');
		if($this->form_validation->run() === true)
		{
			$data	=	[
				"id"			=>	user()->id,
				"first_name"	=>	$this->input->post("first_name"),
				"last_name"		=>	$this->input->post("last_name"),
				"gender"		=>	$this->input->post("gender"),
				"age"			=>	$this->input->post("age"),
				"contact_number"=>	$this->input->post("contact_number"),
				"address"		=>	trim($this->input->post("address"))
			];

			if(user()->account_type == 'teacher')
			{
				$data["department_id"]	=	$this->input->post("department_id");
			}
			
			
			$data['updated_by']	=	user()->id;
			$data['updated_on']	=	date('YYYY-MM-DD HH:mm:ss');

			$response 	=	$this->profile->update($data,user()->account_type);

			if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Profile updated successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to update profile",
				];
			}
			$this->session->set_flashdata("notification.profile",json_encode($type));
			redirect(site_url("profile"));
			
		}else{
			$item = $this->profile->get(user()->id,user()->account_type);
			$departments = $this->profile->get_departments();
			$page = [
				'title' => 'Profile management',
				'breadcrumbs' => 'Profile',
				'pagecode'	=>	'profile',
				'departments' => $departments,
				'item' => $item
			];

			return parent::view('profile/profile',compact('page'));
		}
	}

	public function check_contact_number($contact_number)
	{
		$id  	=	user()->id;
		
		if(!empty($contact_number))
		{
			if($id){
				$condition	=	["id !="=>$id,"contact_number"=>$contact_number];
				$response	=	$this->profile->check_record($condition,user()->account_type);
				
				if($response){
					$this->form_validation->set_message('check_contact_number', 'The '.$contact_number.' is already used. Please enter the new one.');
					return false;
				}
			}else{
				$condition	=	["contact_number"=>$contact_number];
				$response	=	$this->profile->check_record($condition,user()->account_type);
				if($response){
					$this->form_validation->set_message('check_contact_number', 'The '.$contact_number.' is already used. Please enter the new one.');
					return false;
				}
			}
		}

		return true;
	}
}
