<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teachers extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("TeacherModel",'teacher');
	}

	public function index()
	{
		$page = [
			'title' => 'Teachers | Listing',
			'breadcrumbs' => 'Teacher accounts',
			'pagecode'	=>	'teachers'
		];
		return parent::view('teachers/listing',compact('page'));
	}

	public function form($id = null)
	{
		$this->form_validation->set_rules('first_name', 'First name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|callback_check_email');
		$this->form_validation->set_rules('contact_number', 'Contact number', 'required|callback_check_contact_number');
		$this->form_validation->set_rules('department_id', 'Department', 'required');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger m-t-20">', '</div>');
		if($this->form_validation->run() === true)
		{
			$data	=	[
				"id"			=>	$this->input->post("item_id"),
				"first_name"	=>	$this->input->post("first_name"),
				"last_name"		=>	$this->input->post("last_name"),
				"email"			=>	$this->input->post("email"),
				"password"		=>	sha1('123456'),
				"designation_id"=>	0,
				"department_id"	=>	$this->input->post("department_id"),
				"gender"		=>	$this->input->post("gender"),
				"age"			=>	$this->input->post("age"),
				"contact_number"=>	$this->input->post("contact_number"),
				"address"		=>	$this->input->post("address"),
				"status"		=>	'active',
				"is_activated"	=>	1
			];
			
			// update the user details in the database
			if($data["id"]){
				$data['updated_by']	=	user()->id;
				$data['updated_on']	=	date('YYYY-MM-DD HH:mm:ss');
				$response 	=	$this->teacher->update($data);
			}else{
				$data['created_by']	=	user()->id;
				$response 	=	$this->teacher->save($data);
			}

			if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item saved successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to save item",
				];
			}
			$this->session->set_flashdata("notification.teachers",json_encode($type));
			redirect(site_url("teachers"));
			
		}else{

			$item 	=	$this->teacher->get($id);

			$departments = $this->teacher->get_departments();
			$page = [
				'title' => 'Teachers | Add teacher',
				'breadcrumbs' => 'Create teacher account',
				'pagecode'	=>	'teachers',
				'item_id'	=>	$item->id,
				'item'	=>	$item,
				'departments' => $departments
			];
			return parent::view('teachers/form',compact('page'));
		}
		
		
	}

	public function check_email($email)
	{
		$id  	=	$this->input->post("item_id");
	
		if(!empty($email))
		{
			if($id){
				$condition	=	["id !="=>$id,"email"=>$email];
				$response	=	$this->teacher->check_record($condition);
				
				if($response){
					$this->form_validation->set_message('check_email', 'The '.$email.' is already used. Please enter the new one.');
					return false;
				}
			}else{
				$condition	=	["email"=>$email];
				$response	=	$this->teacher->check_record($condition);
				if($response){
					$this->form_validation->set_message('check_email', 'The '.$email.' is already used. Please enter the new one.');
					return false;
				}
			}
		}

		return true;
	}

	public function check_contact_number($contact_number)
	{
		$id  	=	$this->input->post("item_id");
		
		if(!empty($contact_number))
		{
			if($id){
				$condition	=	["id !="=>$id,"contact_number"=>$contact_number];
				$response	=	$this->teacher->check_record($condition);
				
				if($response){
					$this->form_validation->set_message('check_contact_number', 'The '.$contact_number.' is already used. Please enter the new one.');
					return false;
				}
			}else{
				$condition	=	["contact_number"=>$contact_number];
				$response	=	$this->teacher->check_record($condition);
				if($response){
					$this->form_validation->set_message('check_contact_number', 'The '.$contact_number.' is already used. Please enter the new one.');
					return false;
				}
			}
		}

		return true;
	}

	public function ajax_get_items()
	{
		$items		=	$this->teacher->getItems();
		$draw 		= 	intval($this->input->post("draw"));
		
		$total_items	=	$this->teacher->get_total_records();
		$output = array(
			"draw" 				=> $draw,
			"recordsTotal" 		=> $total_items,
			"recordsFiltered" 	=> $total_items,
			"data" 				=> $items
		);
        echo json_encode($output);
        exit();
	}

	public function delete($id){

		$response = $this->teacher->delete($id);

		if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item deleted successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to delete item",
				];
			}
			$this->session->set_flashdata("notification.teachers",json_encode($type));
			redirect(site_url("teachers"));
	}

	public function change_status($id,$status){

		$response = $this->teacher->update(["id"=>$id,"status"=>$status]);

		if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item status changed successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to change status item",
				];
			}
			$this->session->set_flashdata("notification.teachers",json_encode($type));
			redirect(site_url("teachers"));
	}
}
