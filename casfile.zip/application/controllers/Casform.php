<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Casform extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("CasformModel",'cas');
	}

	public function index()
	{
		$this->form_validation->set_rules('cas_group_secret', 'cas_group', 'required');
		if($this->form_validation->run() === true)
		{
			$cas_groups = $this->input->post('cas_groups');
			$cas_group_items = $this->input->post('cas_group_items');

			$data = [
				'student_id'	=>	user()->id,
				'cas_groups'	=>	implode(',',$cas_groups),
				'cas_groups_items' => implode(',',$cas_group_items)
			];

			$response = $this->cas->save($data);

			if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Submission made successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to submit",
				];
			}
			$this->session->set_flashdata("notification.casform",json_encode($type));
			redirect(site_url("casform"));

		}else{
			$categories = $this->cas->get_categories();
			$page = [
				'title' => 'CAS form',
				'breadcrumbs' => 'Fillup the below form',
				'pagecode'	=>	'casform',
				'categories' => $categories
			];
			return parent::view('casform/form',compact('page'));
		}
		
	}

	public function form($id = null)
	{
		$this->form_validation->set_rules('title', 'cas title', 'required|callback_check_slug');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger m-t-20">', '</div>');
		if($this->form_validation->run() === true)
		{
			$data	=	[
				"title"			=>	$this->input->post("title"),
				"slug"			=>	$this->clean($this->input->post("title")),
				"status"		=>	$this->input->post("status"),
				"description"	=>	$this->input->post("description"),
				"id"			=>	$this->input->post("item_id")
			];
			
			// update the user details in the database
			if($data["id"]){
				$data['updated_by']	=	user()->id;
				$data['updated_on']	=	date('YYYY-MM-DD HH:mm:ss');
				$response 	=	$this->cas->update($data);
			}else{
				$data['created_by']	=	user()->id;
				$response 	=	$this->cas->save($data);
			}

			if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item saved successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to save item",
				];
			}
			$this->session->set_flashdata("notification.cas",json_encode($type));
			redirect(site_url("cas"));
			
		}else{

			$item 	=	$this->cas->get($id);

			$page = [
				'title' => 'Add cas group',
				'breadcrumbs' => 'Add cas group',
				'pagecode'	=>	'cas',
				'item_id'	=>	$item->id,
				'item'	=>	$item
			];
			return parent::view('cas/form',compact('page'));
		}
		
	}

	private function clean($string) 
	{
	   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

	   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
	}

	public function check_slug($slug)
	{
		$id  	=	$this->input->post("item_id");
		
		if(empty($slug))
		{
			if(!$this->input->post("item_id"))
			{
				$slug = $this->input->post("title");
			}
		}
		
		if(!empty($slug))
		{
			if($id){
				$condition	=	["id !="=>$id,"slug"=>$slug];
				$response	=	$this->cas->checkSlug($condition);
				
				if($response){
					$this->form_validation->set_message('check_slug', 'The '.$slug.' is already used. Please enter the new and uniqe one.');
					return false;
				}
			}else{
				$condition	=	["slug"=>$slug];
				$response	=	$this->cas->checkSlug($condition);
				if($response){
					$this->form_validation->set_message('check_slug', 'The '.$slug.' is already used. Please enter the new and uniqe one.');
					return false;
				}
				
			}
		}

		return true;
	}

	public function ajax_get_items()
	{
		$items		=	$this->cas->getItems();
		$draw 		= 	intval($this->input->post("draw"));
		
		$total_items	=	$this->cas->get_total_records();
		$output = array(
			"draw" 				=> $draw,
			"recordsTotal" 		=> $total_items,
			"recordsFiltered" 	=> $total_items,
			"data" 				=> $items
		);
        echo json_encode($output);
        exit();
	}

	public function delete($id){

		$response = $this->cas->delete($id);

		if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item deleted successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to delete item",
				];
			}
			$this->session->set_flashdata("notification.cas",json_encode($type));
			redirect(site_url("cas"));
	}

	public function change_status($id,$status){

		$response = $this->cas->update(["id"=>$id,"status"=>$status]);

		if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item status changed successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to change status item",
				];
			}
			$this->session->set_flashdata("notification.cas",json_encode($type));
			redirect(site_url("cas"));
	}
}
