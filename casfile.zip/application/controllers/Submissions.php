<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Submissions extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("SubmissionsModel",'submission');
	}

	public function index()
	{
		$page = [
			'title' => 'CAS submissions',
			'breadcrumbs' => 'CAS submissions',
			'pagecode'	=>	'submissions'
		];
		return parent::view('submissions/listing',compact('page'));
	}

	public function ajax_get_items()
	{
		$items		=	$this->submission->getItems();
		$draw 		= 	intval($this->input->post("draw"));
		
		$total_items	=	$this->submission->get_total_records();
		$output = array(
			"draw" 				=> $draw,
			"recordsTotal" 		=> $total_items,
			"recordsFiltered" 	=> $total_items,
			"data" 				=> $items
		);
        echo json_encode($output);
        exit();
	}

	public function delete($id){

		$response = $this->student->delete($id);

		if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item deleted successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to delete item",
				];
			}
			$this->session->set_flashdata("notification.students",json_encode($type));
			redirect(site_url("students"));
	}

	public function change_status($id,$status){

		$response = $this->student->update(["id"=>$id,"status"=>$status]);

		if($response)
			{
				$type 	=	[
					"type"	=>	"success",
					"msg"	=>	"Item status changed successfully.",
				];
			}else{
				$type 	=	[
					"type"	=>	"error",
					"msg"	=>	"Failed to change status item",
				];
			}
			$this->session->set_flashdata("notification.students",json_encode($type));
			redirect(site_url("students"));
	}
}
