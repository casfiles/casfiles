<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *	This will be user for development purpose.
 */
if(!function_exists("pr"))
{
	function pr($data = NULL)
	{
		echo "<pre>";print_r($data);echo "</pre>";
	}
	
	function prd($data = NULL)
	{
		echo "<pre>";print_r($data);echo "</pre>";die;
	}
}

if(!function_exists("lang"))
{
	function lang($key)
	{
		$ci = & get_instance();
		echo $ci->lang->line($key);
	}
}

if(!function_exists("styles"))
{
	function styles($page = null)
	{
		$style	=	"";
		switch($page)
		{
			case "users":
				$style	=	link_tag(base_url("assets/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/data-table/css/buttons.dataTables.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css"));
				break;
			case "campaigns":
				$style	=	link_tag(base_url("assets/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/data-table/css/buttons.dataTables.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css"));
				break;
			case "gateways":
				$style	=	link_tag(base_url("assets/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/data-table/css/buttons.dataTables.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css"));
				break;
			case "user":
				$style	=	link_tag(base_url("assets/css/bootstrap-datepicker3.standalone.min.css"));
				$style	.=	link_tag(base_url("assets/css/slim.min.css"));
				$style	.=	link_tag(base_url("assets/css/intlTelInput.css"));
				
				break;
			case "category":
				break;
			case "categories":
				$style	=	link_tag(base_url("assets/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/data-table/css/buttons.dataTables.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css"));
				break;
			case "campaigntypes":
				$style	=	link_tag(base_url("assets/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/data-table/css/buttons.dataTables.min.css"));
				$style	.=	link_tag(base_url("assets/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css"));
				break;
			case "campaign":
				$style	 =	link_tag(base_url("assets/css/chosen.min.css"));
				$style	.=	link_tag(base_url("assets/css/bootstrap-datepicker3.standalone.min.css"));
				$style	.=	link_tag(base_url("assets/css/slim.min.css"));
				break;
			case "campaignitem":
				$style	.=	link_tag(base_url("assets/global/plugins/bower_components/bootstrap-fileupload/css/bootstrap-fileupload.min.css"));
				$style	.=	link_tag(base_url("assets/global/plugins/bower_components/bootstrap-daterangepicker/daterangepicker.css"));
				break;
			default:
				break;
		}
		return $style;
	}
}

if(!function_exists("scripts"))
{
	function scripts($page = null)
	{
		$ci		=	&get_instance();
		
		return $ci->load->view($page . '/' . $page . '_js.php','',true);
	}
}

if(!function_exists("email"))
{
	function email($email)
	{
		if(!is_array($email))
		{
			return false;
		}
		return true;
		
		$ci		=	&get_instance();
		$config['protocol'] = 'smtp';
		$config['smtp_host'] = "ssl://mail.privateemail.com";
		$config['smtp_port'] = 465;
		$config['smtp_user'] = "noreply@gofundstart.com";
		$config['smtp_pass'] = "14709c93a006be9459946e2e08bb0186";
		$config['newline'] = "\r\n";
		$config['mailtype'] = 'html';

		$ci->load->library('email', $config);

		$ci->email->set_mailtype("html");
		$ci->email->from(config("from_email"), config("from_name"));
		$ci->email->to($email["to"]);
		$ci->email->subject($email["subject"]);
		$ci->email->message($email["message"]);
		if($ci->email->send())
		{
			return true;
		}else{
			echo $ci->email->print_debugger();die;
			log_message("error","Error in sending email".json_encode($email));
			return false;
		}
	}
}




if(!function_exists("image"))
{
	function image($path = NULL,$attributes = NULL)
	{
		$abssolutePath	=	explode(base_url(),$path);
		$abssolutePath	=	array_filter($abssolutePath);
		$abssolutePath	=	FCPATH . array_pop($abssolutePath);
		if(empty($path))
		{
			return  '<img src="'.base_url("upload/logo/no-logo.png").'" '.$attributes.'/>';
		}else{
			if(!file_exists($abssolutePath))
			{
				return  '<img src="'.base_url("upload/logo/no-logo.png").'" '.$attributes.'/>';
			}else{
				return '<img src='.$path.' '.$attributes.'/>';
			}
		}
	}
}

if(!function_exists("notifications"))
{
	function notification($page)
	{
		$ci		=	&get_instance();
		$msg	=	$ci->session->userdata("notification.".$page);
		$msg	=	json_decode($msg,true);
	
		if(empty($msg))
		{
			return;
		}
		//prd($msg);
		$html 	=	"";
		if(count($msg) > 0)
		{
			switch($msg["type"])
			{
				case "error":
						$class	=	"alert alert-danger background-danger";
					break;
				case "success":
						$class	=	"alert alert-success background-success";
					break;
				case "warning":
						$class	=	"alert alert-warning background-warning";
					break;
				default:
						$class	=	"alert alert-info background-info";
					break;
			}
			
			if(is_array($msg["msg"]) && count($msg["msg"]))
			{
				
				foreach($msg["msg"] as $key=>$val)
				{
					$html	.=	"<div class='".$class."'>";
					$html	.=	$val["msg"];
					$html 	.=	"</div>";
				}
			}else{
				$html	.=	"<div class='".$class."'>";
				$html	.=	$msg["msg"];
				$html 	.=	"</div>";
			}
		}
		echo $html;
	}
}

if(!function_exists("tableObject"))
{
	function tableObject($table = NULL)
	{
		if(empty($table))
		{
			return array();
		}

	$ci = &get_instance();
	$query = $ci->db->query('SHOW COLUMNS FROM '.$ci->db->dbprefix.$table);
	//$result = array();
	$result = new stdClass;
	foreach($query->result() as $key=>$val)
	{
		$result->{$val->Field} = '';
	}
		return $result;
	}
}


if(!function_exists("config"))
{
	function config($settingName = NULL)
	{
		$ci		=	&get_instance();
		if(empty($settingName))
		{
			return NULL;
		}
		$config		=	$ci->db->where("setting_name",$settingName)->get("settings")->row();

		if($config)
		{
			return $config->setting_value;
		}else{
			return NULL;
		}
	}
}

if(!function_exists("isSite"))
{
	function isSite()
	{
		$ci		=	&get_instance();
		$user   = 	$ci->session->userdata("user");
		if(!empty($user))
		{
			$user = stripslashes($user);
			$user = substr($user,1,strlen($user)-2);
			$user 	=	$ci->encryption->decrypt($user);
			$user = json_decode($user,true);
			if(isset($user["id"]) && $user["id"] > 0){
				if(!in_array(3,$user["group_id"])){
					redirect(site_url("login"));
				}
			}else{
				redirect(site_url("login"));
			}
		}else{
			redirect(site_url("login"));
		}
	}
}

if(!function_exists("isAdmin"))
{
	function isAdmin()
	{
		$ci		=	&get_instance();
		$user   = 	$ci->session->userdata("user");
		if(!empty($user))
		{
			$user = stripslashes($user);
			$user = substr($user,1,strlen($user)-2);
			$user 	=	$ci->encryption->decrypt($user);
			$user = json_decode($user,true);
			if(isset($user["id"]) && $user["id"] > 0){
				if(!in_array(1,$user["group_id"])){
					redirect(site_url("login"));
				}
			}else{
				redirect(site_url("login"));
			}
		}else{
			redirect(site_url("login"));
		}
	}
}

if(!function_exists("isLoggedIn"))
{
	function isLoggedIn()
	{
		$ci		=	&get_instance();
		$user   = 	$ci->session->userdata("_user_session_data");

		if(!empty($user))
		{
			$userObj = $ci->encryption->decode($user);

			$userObj = json_decode($userObj,true);
			
			if(!isset($userObj["id"])){
				redirect(site_url("/"));
			}else{
				redirect(site_url("/dashboard"));
			}
		}
	}
}

if(!function_exists("has_access"))
{
	function has_access()
	{
		$ci		=	&get_instance();
		$user   = 	$ci->session->userdata("_user_session_data");

		if(empty($user))
		{
			redirect(site_url("/"));
		}
	}
}


if(!function_exists('user'))
{
	function user()
	{
		$ci		=	&get_instance();
		$ci->load->model("AdminModel");
		$user   = 	$ci->session->userdata("_user_session_data");
	
		if(!empty($user))
		{
			$userObj = $ci->encryption->decode($user);

			$userObj = json_decode($userObj,true);
			$user = $ci->AdminModel->get(["id"=>$userObj["id"]],$userObj['account_type']);
			$user->account_type = $userObj['account_type'];
		}else{
			$user = $ci->AdminModel->get(["id"=>0],'');
		}
		
		return $user;
	}
}

if(!function_exists('countryList'))
{
	function countriesList()
	{
		$ci		=	&get_instance();
		$countries	=	$ci->db->where("status",1)->get("countries")->result();
		if(count($countries) > 0)
		{
			$list = [];
			foreach($countries as $key=>$val)
			{
				$list[$val->id]	=	$val->name;
			}
			
			$countries	=	$list;
		}
		return $countries;
	}
}

if(!function_exists('countryList'))
{
	function statesList($country_id)
	{
		$ci		=	&get_instance();
		$states	=	$ci->db->where(["status"=>1,"country_id"=>$country_id])->get("states")->result();
		if(count($states) > 0)
		{
			$list = [];
			foreach($states as $key=>$val)
			{
				$list[$val->id]	=	$val->name;
			}
			
			$states	=	$list;
		}
		return $states;
	}
}

if(!function_exists('uploadFile'))
{
	function uploadFile($filename,$path,$allowedExtensions,$resize = false)
	{
		$ci		=	&get_instance();
		
		// check if user folder exists
		if (!is_dir($path)) {
			mkdir($path, 0777, TRUE);
		}
		
		$config		=	[];
		$config['upload_path']          = './'.$path;
		$config['allowed_types']        = $allowedExtensions;
		$config['max_size']             = 200000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;
		$config['encrypt_name']         = true;
		$config['overwrite']           	= true;

		$ci->load->library('upload', $config);

		$response 	=	["error"=>null,"data"=>""];
		if ( ! $ci->upload->do_upload($filename))
		{
			$error = array('error' => $ci->upload->display_errors());
			$response["error"]	=	$error["error"];
		}else{
			$filedata = $ci->upload->data();
			$response["data"]	=	$filedata;
		}
		
		// check if need to resize the image
		if($resize){
			$config		=	[];
			$config['image_library'] 	= 	'gd2';
			$config['source_image'] 	= 	$response["data"]["full_path"];
			$config['create_thumb'] 	= 	FALSE;
			$config['maintain_ratio'] 	= 	TRUE;
			$config['width']         	= 	100;
			$config['height']       	= 	100;

			$ci->load->library('image_lib', $config);

			$ci->image_lib->resize();
		}
		return $response;
	}
}

if(!function_exists("campaignProducts"))
{
	function campaignProducts()
	{
		$option = [
			""	=> "-- Select Form Fields --",
			"form_project"	=>	"Projects",
			"form_patron"	=>	"Patrons",
			"form_investment"	=>	"Investments"
		];
		return $option;
	}
}

if(!function_exists("get_setup_file_html"))
{
	function get_setup_file_html($filename, $data)
	{
		$html	=	"";
		try{
			$filepath	=	FCPATH ."assets/gateways/".$filename;
			$data		=	json_decode($data,true);
			if(!file_exists($filepath))
			{
				$html	 =	"<div class='alert alert-info'>";
				$html 	.=	"Setup file does not exist for this channel please either check the file directory or upload new one";
				$html 	.=	"</div>";
				return $html;
			}
			$doc = new DOMDocument();
			$doc->load( $filepath );//xml file loading here

			$extension = $doc->getElementsByTagName( "extension" );
			if($extension->length)
			{
				$errorFlag	=	0;
				$attributesCount	=	0;
				foreach( $extension[0]->childNodes as $key=>$val )
				{
					if($val instanceOf DOMElement)
					{
						if($val->tagName == "fields")
						{
							
							foreach($val->childNodes as $k=>$v)
							{
								if($v instanceOf DOMElement)
								{
									if($v->hasAttribute("name") && $v->hasAttribute("type") && $v->hasAttribute("label"))
									{
										if($v->hasAttribute("class"))
										{
											$class	=	$v->getAttribute("class");
										}else{
											$class	=	"";
										}
										
										$value	=	(isset($data[$v->getAttribute("name")]))?$data[$v->getAttribute("name")]:"";
										if($v->getAttribute("type") == "hidden")
										{
											$html	.=	"<input type='".$v->getAttribute("type")."' name='api[".$v->getAttribute("name")."]' value='".$v->getAttribute("value")."'/>";
										}else{
											$html 	.=	'<div class="form-group">';
											$html 	.=	'<label for="'.$v->getAttribute("name").'">'.ucfirst($v->getAttribute("label")).'</label>';
											$html	.=	"<input type='".$v->getAttribute("type")."' name='api[".$v->getAttribute("name")."]' id='".$v->getAttribute("name")."'  class='form-control ".$class."' value='".$value."'/>";
											$html  	.=	"</div>";
										}
									}else{
										$errorFlag++;
									}
									$attributesCount++;
								}
							}
						}
					}
				}
				
				if($errorFlag == $attributesCount)
				{
					$html	 =	"<div class='alert alert-info'>";
					$html 	.=	" Format of the setup file is not valid please check the format of the file";
					$html 	.=	"</div>";
				}
			}else{
				$html	 =	"<div class='alert alert-info'>";
				$html 	.=	" Format of the setup file is not valid please check the format of the file";
				$html 	.=	"</div>";
			}
		}catch(Exception $e){
			$html	 =	"<div class='alert alert-info'>";
			$html 	.=	$e->getMessage();
			$html 	.=	"</div>";
		}
		return $html;
	}
}



