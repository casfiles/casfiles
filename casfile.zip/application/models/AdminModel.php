<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get(array $where,$login_type)
	{
		switch($login_type)
		{
			case 'admin':
				$row	=	$this->db->get_where("admins",$where)->row();
				break;
			case 'teacher':
				$row	=	$this->db->get_where("teachers",$where)->row();
				break;
			case 'student':
				$row	=	$this->db->get_where("students",$where)->row();
				break;
			default:
				return;
				break;
		}
		
		if($row){
			return $row;
		}else{
			return tableObject("teachers");
		}
	}
	
	public function save($data)
	{
		$this->db->insert("students",$data);
		return $this->db->insert_id();
	}	
}
