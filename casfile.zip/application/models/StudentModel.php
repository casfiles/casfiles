<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get($id = null)
	{
		if($id)
		{
			$category	=	$this->db->where("id",$id)->get("students")->row();	
			if(!$category)
			{
				return tableObject("students");
			}
			return $category;
		}else{
			return tableObject("students");
		}
	}
	
	public function getItems()
	{
		$start 		= 	(int)$this->input->post("start");
		$length 	= 	(int)$this->input->post("length");
		
		$length		=	($length)?$length:10;
		
		$columns		=	$this->input->post("columns");
		$order			=	$this->input->post("order");
		$order_by		=	(isset($columns[$order[0]["column"]]))?$columns[$order[0]["column"]]['data']:"id";
		$direction		=	(isset($order[0]["dir"]))?$order[0]["dir"]:"desc";
		
		$this->db->select("t.id,t.first_name,t.email,t.contact_number,t.status,t.created_on")->from("students as t");
		$search			=	$this->input->post("search");
		if(isset($search["value"]) && !empty($search["value"]))
		{
			$this->db->group_start();
			$this->db->or_like(["t.first_name"=>$search["value"]]);
			$this->db->or_like(["t.last_name"=>$search["value"]]);
			$this->db->group_end();
		}
		
		$this->db->order_by($order_by." ".$direction);
		$this->db->limit($length,$start);
		
		$records 	=	$this->db->get()->result_array();
		return $records;
	}
	
	public function get_total_records()
	{
		$this->db->select("COUNT(id) AS TotalRecord");
		$this->db->from("students");
		$total_record 	=	$this->db->get()->row();
		if($total_record)
		{
			return $total_record->TotalRecord;
		}else{
			return 0;
		}
	}
	
	public function getCategoryDropDown($id)
	{
		$categories		=	$this->db->where("id !=",$id)->get("students")->result();
		$catArray	=	["0"=>"-- Select Category --"];
		if(count($categories) > 0){
			foreach($categories as $key=>$val){
				$catArray[$val->id]		=	$val->title;
			}
			$categories		=	$catArray;
		}
		return $categories;
	}
	
	public function update($data)
	{
		$id 	=	$data["id"];
		unset($data["id"]);
		$this->db->where("id",$id)->update("students",$data);
		return $this->db->affected_rows();
	}
	
	public function save($data)
	{
		$this->db->insert("students",$data);
		return $this->db->insert_id();
	}
	
	public function delete($id)
	{
		$this->db->where("id",$id)->delete("students");
		return $this->db->affected_rows();
	}	
	
	public function check_record($where)
	{
		return $this->db->where($where)->count_all_results("students");
	}

	public function get_departments()
	{
		$rows =  $this->db->where(['status' => 'active'])->get("departments")->result_array();

		if($rows)
		{
			$list = [];
			foreach($rows as $key => $val)
			{
				$list[$val['id']] = $val['title'];
			}

			return $list;
		}

		return [];
	}
}
