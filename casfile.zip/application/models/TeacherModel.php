<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TeacherModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get($id = null)
	{
		if($id)
		{
			$category	=	$this->db->where("id",$id)->get("teachers")->row();	
			if(!$category)
			{
				return tableObject("teachers");
			}
			return $category;
		}else{
			return tableObject("teachers");
		}
	}
	
	public function getItems()
	{
		$start 		= 	(int)$this->input->post("start");
		$length 	= 	(int)$this->input->post("length");
		
		$length		=	($length)?$length:10;
		
		$columns		=	$this->input->post("columns");
		$order			=	$this->input->post("order");
		$order_by		=	(isset($columns[$order[0]["column"]]))?$columns[$order[0]["column"]]['data']:"id";
		$direction		=	(isset($order[0]["dir"]))?$order[0]["dir"]:"desc";
		
		$this->db->select("t.id,t.first_name,t.email,d.title as department,t.contact_number,t.status,t.created_on")->from("teachers as t");
		$this->db->join("departments as d","d.id=t.department_id","LEFT");
		$search			=	$this->input->post("search");
		if(isset($search["value"]) && !empty($search["value"]))
		{
			$this->db->group_start();
			$this->db->or_like(["t.first_name"=>$search["value"]]);
			$this->db->or_like(["d.name"=>$search["value"]]);
			$this->db->group_end();
		}
		
		$this->db->order_by($order_by." ".$direction);
		$this->db->limit($length,$start);
		
		$records 	=	$this->db->get()->result_array();
		return $records;
	}
	
	public function get_total_records()
	{
		$this->db->select("COUNT(id) AS TotalRecord");
		$this->db->from("teachers");
		$total_record 	=	$this->db->get()->row();
		if($total_record)
		{
			return $total_record->TotalRecord;
		}else{
			return 0;
		}
	}
	
	public function getCategoryDropDown($id)
	{
		$categories		=	$this->db->where("id !=",$id)->get("teachers")->result();
		$catArray	=	["0"=>"-- Select Category --"];
		if(count($categories) > 0){
			foreach($categories as $key=>$val){
				$catArray[$val->id]		=	$val->title;
			}
			$categories		=	$catArray;
		}
		return $categories;
	}
	
	public function update($data)
	{
		$id 	=	$data["id"];
		unset($data["id"]);
		$this->db->where("id",$id)->update("teachers",$data);
		return $this->db->affected_rows();
	}
	
	public function save($data)
	{
		$this->db->insert("teachers",$data);
		return $this->db->insert_id();
	}
	
	public function delete($id)
	{
		$this->db->where("id",$id)->delete("teachers");
		return $this->db->affected_rows();
	}	
	
	public function check_record($where)
	{
		return $this->db->where($where)->count_all_results("teachers");
	}

	public function get_departments()
	{
		$rows =  $this->db->where(['status' => 'active'])->get("departments")->result_array();

		if($rows)
		{
			$list = [];
			foreach($rows as $key => $val)
			{
				$list[$val['id']] = $val['title'];
			}

			return $list;
		}

		return [];
	}
}
