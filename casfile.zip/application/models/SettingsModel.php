<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SettingsModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function update_password($data,$login_type)
	{
		switch($login_type)
		{
			case 'admin':
				$id = $data["id"];
				unset($data["id"]);
				$this->db->where("id",$id)->update("admins",$data);
				return $this->db->affected_rows();
				break;
			case 'teacher':
				$id = $data["id"];
				unset($data["id"]);
				$this->db->where("id",$id)->update("teachers",$data);
				return $this->db->affected_rows();
				break;
			case 'student':
				$id = $data["id"];
				unset($data["id"]);
				$this->db->where("id",$id)->update("students",$data);
				return $this->db->affected_rows();
				break;
			default:
				return;
				break;
		}
		
		return false;
	}

	public function check_record($where,$login_type)
	{
		switch($login_type)
		{
			case 'admin':
				return $this->db->where($where)->count_all_results("admins");
				break;
			case 'teacher':
				return $this->db->where($where)->count_all_results("teachers");
				break;
			case 'student':
				return $this->db->where($where)->count_all_results("students");
				break;
			default:
				return;
				break;
		}
		
	}
}
