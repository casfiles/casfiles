<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProfileModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get($id = null,$account_type)
	{
		if($id)
		{
			if($account_type == 'teacher'){
				$category	=	$this->db->where("id",$id)->get("teachers")->row();	
			}else{
				$category	=	$this->db->where("id",$id)->get("students")->row();	
			}
			
			if(!$category)
			{
				if($account_type == 'teacher'){
					return tableObject("teachers");
				}else{
					return tableObject("students");
				}
			}
			return $category;
		}else{
			if($account_type == 'teacher'){
				return tableObject("teachers");
			}else{
				return tableObject("students");
			}
		}
	}
	
	
	public function update($data,$account_type)
	{
		$id 	=	$data["id"];
		unset($data["id"]);

		if($account_type == 'teachers'){
			$this->db->where("id",$id)->update("teachers",$data);
			return $this->db->affected_rows();
		}else{
			$this->db->where("id",$id)->update("students",$data);
			return $this->db->affected_rows();
		}
		
	}

	
	public function check_record($where,$account_type)
	{
		if($account_type == 'teachers'){
			return $this->db->where($where)->count_all_results("teachers");
		}else{
			return $this->db->where($where)->count_all_results("students");
		}
	}

	public function get_departments()
	{
		$rows =  $this->db->where(['status' => 'active'])->get("departments")->result_array();

		if($rows)
		{
			$list = [];
			foreach($rows as $key => $val)
			{
				$list[$val['id']] = $val['title'];
			}

			return $list;
		}

		return [];
	}
}
