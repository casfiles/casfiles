<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CasitemsModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get($id = null)
	{
		if($id)
		{
			$category	=	$this->db->where("id",$id)->get("cas")->row();	
			if(!$category)
			{
				return tableObject("cas");
			}
			return $category;
		}else{
			return tableObject("cas");
		}
	}
	
	public function getItems()
	{
		$start 		= 	(int)$this->input->post("start");
		$length 	= 	(int)$this->input->post("length");
		
		$length		=	($length)?$length:10;
		
		$columns		=	$this->input->post("columns");
		$order			=	$this->input->post("order");
		$order_by		=	(isset($columns[$order[0]["column"]]))?$columns[$order[0]["column"]]['data']:"id";
		$direction		=	(isset($order[0]["dir"]))?$order[0]["dir"]:"desc";

		$this->db->select("c.*,cc.title as cas_group")->from("cas as c");
		$this->db->join("cas as cc","cc.id = c.parent_id","LEFT");
		$this->db->where(['c.parent_id !=' => 0]);
		$search			=	$this->input->post("search");
		if(isset($search["value"]) && !empty($search["value"]))
		{
			$this->db->group_start();
			$this->db->or_like(["title"=>$search["value"]]);
			$this->db->group_end();
		}
		
		$this->db->order_by($order_by." ".$direction);
		$this->db->limit($length,$start);
		
		$records 	=	$this->db->get()->result_array();
		return $records;
	}
	
	public function get_total_records()
	{
		$this->db->select("COUNT(id) AS TotalRecord");
		$this->db->from("cas");
		$this->db->where(['parent_id !=' => 0]);
		$total_record 	=	$this->db->get()->row();
		if($total_record)
		{
			return $total_record->TotalRecord;
		}else{
			return 0;
		}
	}
	
	public function getCategoryDropDown($id)
	{
		$categories		=	$this->db->where("id !=",$id)->get("departments")->result();
		$catArray	=	["0"=>"-- Select Category --"];
		if(count($categories) > 0){
			foreach($categories as $key=>$val){
				$catArray[$val->id]		=	$val->title;
			}
			$categories		=	$catArray;
		}
		return $categories;
	}
	
	public function update($data)
	{
		$id 	=	$data["id"];
		unset($data["id"]);
		$this->db->where("id",$id)->update("cas",$data);
		return $this->db->affected_rows();
	}
	
	public function save($data)
	{
		$this->db->insert("cas",$data);
		return $this->db->insert_id();
	}
	
	public function delete($id)
	{
		$this->db->where("id",$id)->delete("cas");
		return $this->db->affected_rows();
	}	
	
	public function checkSlug($where)
	{
		return $this->db->where($where)->count_all_results("cas");
	}

	public function get_groups()
	{
		$rows =  $this->db->where(['status' => 'active','parent_id' => 0])->get("cas")->result_array();

		if($rows)
		{
			$list = [];
			foreach($rows as $key => $val)
			{
				$list[$val['id']] = $val['title'];
			}

			return $list;
		}

		return [];
	}

	
}
