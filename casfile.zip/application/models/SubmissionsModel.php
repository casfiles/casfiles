<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SubmissionsModel extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get($id = null)
	{
		if($id)
		{
			$category	=	$this->db->where("id",$id)->get("students")->row();	
			if(!$category)
			{
				return tableObject("students");
			}
			return $category;
		}else{
			return tableObject("students");
		}
	}
	
	public function getItems()
	{
		$start 		= 	(int)$this->input->post("start");
		$length 	= 	(int)$this->input->post("length");
		
		$length		=	($length)?$length:10;
		
		$columns		=	$this->input->post("columns");
		$order			=	$this->input->post("order");
		$order_by		=	(isset($columns[$order[0]["column"]]))?$columns[$order[0]["column"]]['data']:"id";
		$direction		=	(isset($order[0]["dir"]))?$order[0]["dir"]:"desc";
		
		$this->db->select("c.*,s.first_name")->from("cas_submissions as c");
		$this->db->join("students as s","s.id=c.student_id","LEFT");

		$search			=	$this->input->post("search");
		if(isset($search["value"]) && !empty($search["value"]))
		{
			$this->db->group_start();
			$this->db->or_like(["s.first_name"=>$search["value"]]);
			$this->db->or_like(["s.last_name"=>$search["value"]]);
			$this->db->group_end();
		}
		
		$this->db->order_by($order_by." ".$direction);
		$this->db->limit($length,$start);
		
		$records 	=	$this->db->get()->result_array();

		if(count($records) > 0)
		{
			foreach($records as $key => &$val)
			{
				$cas_groups = explode(",",$val['cas_groups']);

				foreach($cas_groups as $k => $v)
				{
					$this->db->or_where('id',$v);
				}
				$result = $this->db->get('cas')->result_array();

				if($result){
					$cg = [];
					foreach($result as $k => $v){
						$cg[] =$v['title'];
					}

					$val['cas_groups'] = implode(',',$cg);
				}

				$cas_groups_items = explode(",",$val['cas_groups_items']);

				foreach($cas_groups_items as $k => $v)
				{
					$this->db->or_where('id',$v);
				}
				$result = $this->db->get('cas')->result_array();

				if($result){
					$cg = [];
					foreach($result as $k => $v){
						$cg[] =$v['title'];
					}

					$val['cas_groups_items'] = implode(',',$cg);
				}
			}
		}

		return $records;
	}
	
	public function get_total_records()
	{
		$this->db->select("COUNT(id) AS TotalRecord");
		$this->db->from("students");
		$total_record 	=	$this->db->get()->row();
		if($total_record)
		{
			return $total_record->TotalRecord;
		}else{
			return 0;
		}
	}
	
	public function getCategoryDropDown($id)
	{
		$categories		=	$this->db->where("id !=",$id)->get("students")->result();
		$catArray	=	["0"=>"-- Select Category --"];
		if(count($categories) > 0){
			foreach($categories as $key=>$val){
				$catArray[$val->id]		=	$val->title;
			}
			$categories		=	$catArray;
		}
		return $categories;
	}
	
	public function update($data)
	{
		$id 	=	$data["id"];
		unset($data["id"]);
		$this->db->where("id",$id)->update("students",$data);
		return $this->db->affected_rows();
	}
	
	public function save($data)
	{
		$this->db->insert("students",$data);
		return $this->db->insert_id();
	}
	
	public function delete($id)
	{
		$this->db->where("id",$id)->delete("students");
		return $this->db->affected_rows();
	}	
	
	public function check_record($where)
	{
		return $this->db->where($where)->count_all_results("students");
	}

	public function get_departments()
	{
		$rows =  $this->db->where(['status' => 'active'])->get("departments")->result_array();

		if($rows)
		{
			$list = [];
			foreach($rows as $key => $val)
			{
				$list[$val['id']] = $val['title'];
			}

			return $list;
		}

		return [];
	}
}
