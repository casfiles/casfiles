<script type="text/javascript">
$(document).ready(function(){
	if($(".items").length){
		$('.items').DataTable({
			"responsive": true,
			"processing": true,
			"serverSide": true,
			"ajax": {
				url : "<?php echo site_url("get-submission-items");?>",
				type: "post",
				data:{'<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>'},
				complete: function ( json ) {
				}
			},
			"columns": [
					{ "data": "id" },
					{ "data": "first_name",render : function (data, type, row){
						return data;
					} },
					{ "data": "cas_groups" },
					{ "data": "cas_groups_items" },
					{ "data": "submitted_on" }
				  ],
			'columnDefs': [{
				 'targets': 4,
				 'searchable': false,
				 'orderable': true,
			  }
			],
			order: [[ 1, 'asc' ]]
		});
	}
});
</script>