<div class="col-12">
    <!-- Custom Tabs -->
    <div class="card">
        <div class="card-header ">
            CAS form submissions
        </div><!-- /.card-header -->
        <div class="card-body">
            <table class="table table-bordered table-hover items">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student</th>
                        <th>CAS groups</th>
                        <th>cas group items</th>
                        <th>Submitted on</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        <!-- /.tab-content -->
        </div><!-- /.card-body -->
    </div>
    <!-- ./card -->
</div>