</div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2019</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 0.0.1
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo site_url('assets/plugins/jquery/jquery.min.js');?>"></script>
<script src="<?php echo site_url('assets/plugins/DataTables/datatables.min.js');?>"></script>
<!-- Bootstrap -->
<script src="<?php echo site_url('assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>

<!-- AdminLTE -->
<script src="<?php echo site_url('assets/js/adminlte.js');?>"></script>

<!-- OPTIONAL SCRIPTS -->

<?php echo scripts($page["pagecode"]);?>
</body>
</html>
