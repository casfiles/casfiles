<div class="col-12">
    <!-- Custom Tabs -->
    <div class="card">
        <div class="card-header ">
            Departments
            <div class="card-tools">
                <a href="<?php echo site_url('add-department');?>" class="btn btn-primary btn-sm" name="submit">
                    <i class="fas fa-plus"></i>&nbsp;Add department
                </a>
            </div>
        </div><!-- /.card-header -->
        <div class="card-body">
            <table class="table table-bordered table-hover items">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Created On</th>
                        <th>Created By</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        <!-- /.tab-content -->
        </div><!-- /.card-body -->
    </div>
    <!-- ./card -->
</div>
