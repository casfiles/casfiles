<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>School administration</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?php echo site_url('assets/plugins/fontawesome-free/css/all.min.css');?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/adminlte.min.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/adminlte.min.css.map');?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="<?php echo site_url();?>"><b>School&nbsp;</b>Administration</a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <?php echo form_open(site_url(''),["id"=>"login-form","novalidate"=>true,"class"=>"","role"=>"form"]);?>
        <div class="form-group">
          <label>Sign in as</label>
          <?php echo form_dropdown("login_type",['admin'=>'Administration','teacher'=>'Teacher','student'=>'Student'],set_value("login_type"),['class'=>'form-control']);?>
        </div>
        <div class="input-group mb-3">
          <input name="email" type="email" class="form-control" placeholder="Email" value="<?php echo set_value("email");?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <?php echo form_error("email");?>
        <div class="input-group mb-3">
          <input name="password" type="password" class="form-control" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <?php echo form_error("password");?>
        <div class="row">
          <!-- /.col -->
          <div class="col-12">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      <?php echo form_close();?>

      <p class="mb-1 d-none">
		    <a href="<?php echo site_url('forget-password');?>">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="<?php echo site_url('register-account');?>" class="text-center">Register account</a>
      </p>
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<script src="<?php echo site_url('assets/plugins/jquery/jquery.min.js');?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo site_url('assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<script src="<?php echo site_url('assets/js/adminlte.min.js');?>"></script>

</body>
</html>
