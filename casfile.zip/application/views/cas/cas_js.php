<script type="text/javascript">
$(document).ready(function(){
	if($(".items").length){
		$('.items').DataTable({
			"responsive": true,
			"processing": true,
			"serverSide": true,
			"ajax": {
				url : "<?php echo site_url("get-cas-items");?>",
				type: "post",
				data:{'<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>'},
				complete: function ( json ) {
				}
			},
			"columns": [
					{ "data": "id" },
					{ "data": "title",render : function (data, type, row){
						var html = '';
						html +=	data+"<br/><a href='edit-cas/"+row.id+"' class='btn small btn-sm btn-success'><i class='fa fa-edit'></i></a>";
						html += "&nbsp;<a href='delete-cas/"+row.id+"' class='btn btn-sm btn-danger'> <i class='fa fa-trash'></i></a>";
						
						if(row.status == 'active'){
							html += "&nbsp;<a href='change-cas-status/"+row.id+"/inactive' class='btn btn-sm btn-secondary'> <i class='far fa-thumbs-down'></i></a>";
						}else if(row.status == 'inactive'){
							html += "&nbsp;<a href='change-cas-status/"+row.id+"/active' class='btn btn-sm btn-secondary'> <i class='far fa-thumbs-up'></i></a>";
						}
						return html;
					} },
					{ "data": "description" },
					{ "data": "status", render : function (data, type, row){
						if(data == 'active'){
							return '<label class="badge badge-success">' + data + '</label>';
						}else{
							return '<label class="badge badge-danger">' + data + '</label>';
						}
					}},
					{ "data": "created_on" },
					{ "data": "created_by" },
				  ],
			'columnDefs': [{
				 'targets': 4,
				 'searchable': false,
				 'orderable': true,
			  }
			],
			order: [[ 1, 'asc' ]]
		});
	}
});
</script>