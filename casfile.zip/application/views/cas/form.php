<?php 
	$link 	=	(isset($page["item_id"]) && !empty($page['item_id']))?"edit-cas/".$page["item_id"]:"add-cas";
?>
<?php echo form_open(site_url($link),["id"=>"item","name"=>"item","class"=>"item-form"]);?>
    <input type="hidden" name="item_id" value="<?php echo $page['item_id'];?>"/>
    <div class="col-12">
        <!-- Custom Tabs -->
        <div class="card">
            <div class="card-header ">
                CAS group
                <div class="card-tools">
                    <a class="btn btn-secondary btn-sm" href="<?php echo site_url('cas');?>">
                        <i class="fas fa-arrow-left"></i>&nbsp;Cancel
                    </a>
                    <button type="submit" class="btn btn-primary btn-sm" name="submit">
                        <i class="fas fa-save"></i>&nbsp;Save
                    </button>
                </div>
            </div><!-- /.card-header -->
            <div class="card-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Title</label>
                    <input name="title" type="text" class="form-control" placeholder="CAS Title" value="<?php echo $page['item']->title;?>">
                </div>
                <?php echo form_error("title");?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Description</label>
                    <textarea name="description" class="form-control" rows="5" placeholder="CAS description"><?php echo $page['item']->description;?></textarea>
                </div>
                <?php echo form_error("description");?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Status</label>
                    <?php echo form_dropdown('status',["active"=>"ACTIVE","inactive"=>"INACTIVE"],$page['item']->status,["class"=>"form-control"]);?>
                </div>
                <?php echo form_error("status");?>
            <!-- /.tab-content -->
            </div><!-- /.card-body -->
        </div>
        <!-- ./card -->
    </div>
<?php echo form_close();?>