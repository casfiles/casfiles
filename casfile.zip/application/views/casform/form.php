<?php echo form_open(site_url('casform'),["id"=>"item","name"=>"item","class"=>"item-form"]);?>
    <input type="hidden" name="cas_group_secret" value="1"/>
    <div class="card">
        <div class="card-header ">
            CAS Selection Form
            <div class="card-tools">
                <button type="submit" class="btn btn-primary btn-sm" name="submit">
                    <i class="fas fa-save"></i>&nbsp;Submit
                </button>
            </div>
        </div><!-- /.card-header -->
        <div class="card-body">
            <?php if(count($page['categories']) == 0):?>
                <div class="alert alert-info">
                    Currently no form available for filling
                </div>
            <?php else:?>
                <?php //pr($page['categories']);?>
                <?php foreach($page['categories'] as $key => $val):?>
                    <input type="hidden" name="cas_groups[]" value="<?php echo $val['id'];?>"/>
                    <div class="form-group">
                        <lable><?php echo ucfirst($val['title']);?></label>
                        <?php echo form_dropdown('cas_group_items[]',$val['childrens'],'',['class'=>'form-control'])?>
                    </div>
                <?php endforeach;?>
            <?php endif;?>
        </div><!-- /.card-body -->
    </div>
<?php echo form_close();?>