<?php echo form_open(site_url('settings'),["id"=>"change-password","name"=>"change-password"]);?>
	<div class="form-group">
		<label class="control-label">Current Password</label>
		<input type="password" class="form-control" name="current_password" value=""/>
		<?php echo form_error("current_password");?>
	</div>
	<div class="form-group">
		<label class="control-label">New Password</label>
		<input type="password" class="form-control" name="new_password" value=""/>
		<?php echo form_error("new_password");?>
	</div>
	<div class="form-group">
		<label class="control-label">Confirm Password</label>
		<input type="password" class="form-control" name="confirm_password" value=""/>
		<?php echo form_error("confirm_password");?>
	</div>
	<div class="form-group text-right">
		<button class="btn btn-primary btn-sm" type="submit">
			<i class="fa fa-save"></i> Submit
		</button>
	</div>
<?php echo form_close();?>