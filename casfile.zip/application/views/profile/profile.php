<?php echo form_open(site_url('profile'),["id"=>"item","name"=>"item","class"=>"item-form"]);?>
    <div class="col-12">
        <!-- Custom Tabs -->
        <div class="card">
            <div class="card-header ">
                Profile
                <div class="card-tools">
                    <button type="submit" class="btn btn-primary btn-sm" name="submit">
                        <i class="fas fa-save"></i>&nbsp;Save
                    </button>
                </div>
            </div><!-- /.card-header -->
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">First name</label>
                            <input type="text" name="first_name" class="form-control" placeholder="Your first name" value="<?php echo $page['item']->first_name;?>">
                        </div>
                        <?php echo form_error("first_name");?>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Last name</label>
                            <input type="text" name="last_name"  class="form-control" placeholder="Your first name" value="<?php echo $page['item']->last_name;?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Age</label>
                            <input type="text" name="age" class="form-control" placeholder="Your first name" value="<?php echo $page['item']->age;?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Gender</label>
                            <?php echo form_dropdown('gender',['male'=>'MALE','female'=>'FEMALE','other'=>'OTHER'],$page['item']->gender,['class'=>'form-control']);?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="text" name="email" class="form-control" placeholder="Your first name" value="<?php echo $page['item']->email;?>" disabled>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Contact Number</label>
                            <input type="text" name="contact_number" class="form-control" placeholder="Your first name" value="<?php echo $page['item']->contact_number;?>">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Address</label>
                            <textarea type="text" name="address" class="form-control" placeholder="Your first name">
                                <?php echo $page['item']->address;?>
                            </textarea>
                        </div>
                    </div>
                    <?php if(user()->account_type == 'teacher'):?>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Department</label>
                            <?php echo form_dropdown('department_id',$page['departments'],$page['item']->department_id,['class'=>'form-control']);?>
                        </div>
                        <?php echo form_error("department_id");?>
                    </div>
                    <?php endif;?>
                </div>
                
            <!-- /.tab-content -->
            </div><!-- /.card-body -->
        </div>
        <!-- ./card -->
    </div>
<?php echo form_close();?>