<div class="col-12">
    <!-- Custom Tabs -->
    <div class="card">
        <div class="card-header ">
            Accounts
            <div class="card-tools">
                <a href="<?php echo site_url('add-student');?>" class="btn btn-primary btn-sm" name="submit">
                    <i class="fas fa-plus"></i>&nbsp;Add account
                </a>
            </div>
        </div><!-- /.card-header -->
        <div class="card-body">
            <table class="table table-bordered table-hover items">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact Number</th>
                        <th>Status</th>
                        <th>Registered On</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        <!-- /.tab-content -->
        </div><!-- /.card-body -->
    </div>
    <!-- ./card -->
</div>