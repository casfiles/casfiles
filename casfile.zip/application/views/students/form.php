<?php 
	$link 	=	(isset($page["item_id"]) && !empty($page['item_id']))?"edit-student/".$page["item_id"]:"add-student";
?>
<?php echo form_open(site_url($link),["id"=>"item","name"=>"item","class"=>"item-form"]);?>
    <input type="hidden" name="item_id" value="<?php echo $page['item_id'];?>"/>
    <div class="col-12">
        <!-- Custom Tabs -->
        <div class="card">
            <div class="card-header ">
                Profile
                <div class="card-tools">
                    <button type="submit" class="btn btn-primary btn-sm" name="submit">
                        <i class="fas fa-save"></i>&nbsp;Save
                    </button>
                </div>
            </div><!-- /.card-header -->
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">First name</label>
                            <input type="text" value="<?php echo $page['item']->first_name;?>" name="first_name" class="form-control" placeholder="Your first name">
                        </div>
                        <?php echo form_error("first_name");?>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Last name</label>
                            <input type="text" name="last_name" value="<?php echo $page['item']->last_name;?>" class="form-control" placeholder="Your last name">
                        </div>
                        <?php echo form_error("last_name");?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Age</label>
                            <input type="number" min="18" name="age" value="<?php echo $page['item']->age;?>" class="form-control" placeholder="Age">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Gender</label>
                            <?php echo form_dropdown('gender',['male'=>'MALE','female'=>'FEMALE','other'=>'OTHER'],$page['item']->gender,['class'=>'form-control']);?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $page['item']->email;?>" placeholder="Your email">
                        </div>
                        <?php echo form_error("email");?>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Contact Number</label>
                            <input type="text" name="contact_number" class="form-control" value="<?php echo $page['item']->contact_number;?>" placeholder="Your  contact number">
                        </div>
                        <?php echo form_error("contact_number");?>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Address</label>
                            <textarea type="text" class="form-control" placeholder="Your address" name="address">
                                <?php echo $page['item']->address;?>
                            </textarea>
                        </div>
                    </div>
                </div>
            <!-- /.tab-content -->
            </div><!-- /.card-body -->
        </div>
        <!-- ./card -->
    </div>
<?php echo form_close();?>